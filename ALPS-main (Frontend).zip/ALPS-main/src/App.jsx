import { useState } from "react";
import "./App.css";
import Login from "./Components/Login";
import { CssBaseline, ThemeProvider} from "@mui/material";
import createTheme from '@mui/material/styles/createTheme';
import { Navigate, Route, Routes } from "react-router-dom";
import Dashboard from "./Components/Dashboard/dashboard";
import Layout from "./Components/GlobalComponent/layout";
import Program from "./Components/Program/Program";
import Details from "./Components/ApplicationRequest/details";
import Stepper from "./Components/PersonalDetails/StepperApply";
import StepperReviewer from "./Components/Reviewer/StepperReviewer";
import ProgramDetails from "./Components/ProgramDetails/ProgramDetails";
import Approver from "./Components/Reviewer/Approval";
import { SnackProvider } from "./Components/GlobalComponent/SnackProvider";
 
const defaultTheme = createTheme();
 
function App() {
  const [user, setUser] = useState(0);
 
  return (
    <div className="App">
      {!localStorage.getItem("userEmail") ? (
        <Login setUser={setUser} />
      ) : (
        <>
          <ThemeProvider theme={defaultTheme}>
            <CssBaseline />
            <SnackProvider>
            <Routes>
              <Route element={<Layout user={user} setUser={setUser} />}>
                <Route index element={<Navigate to="/dashboard" />} />
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="create" element={<Program />} />
                <Route path="program-details" element={<ProgramDetails />} />
                <Route path="Details" element={<Details/>}/>
                <Route path="apply" element={<Stepper/>}/>
                <Route path="review" element={<StepperReviewer/>}/>
                <Route path="approve" element={<Approver/>}/>
              </Route>
            </Routes>
            </SnackProvider>
          </ThemeProvider>
        </>
      )}
    </div>
  );
}
 
export default App;