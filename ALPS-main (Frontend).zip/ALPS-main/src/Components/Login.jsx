import React, { useState } from "react";
import {
  TextField,
  Button,
  FormControlLabel,
  Typography,
  Box,
  Grid,
  InputAdornment,
  IconButton,
} from "@mui/material";
import { styled } from "@mui/system";
import Image from "../assets/Login.png";
import Logo from "../assets/logo_full.png";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import credentials from "./json/user.json";
import CustomCheckbox from "./Login/CustomCheckBox";

const ImageContainer = styled(Box)({
  backgroundImage: `url(${Image})`,
  backgroundSize: "cover",
  backgroundPosition: "center",
  width:'90vh',
  height: "90vh",
  margin: "2rem",
  borderRadius: "2%",
});

const LogoContainer = styled(Box)({
  position: "absolute",
  top: "3rem",
  left: "5rem",
  width: "150px",
  height: "8vh",
});

const LoginForm = styled(Box)({
  display: "flex",
  justifyContent: "center",
  flexDirection: "column",
  padding: "1rem",
  width: "100%",
  maxWidth: "300px",
});

const LoginTextField = styled(TextField)({
  "& .MuiOutlinedInput-root": {
    "& .MuiInputBase-root": {
      border: `1px solid #CCCCCC`,
      boxShadow: `inset 0px 3px 6px #00000029`,
      background: `#FFFFFF 0% 0% no-repeat padding-box`,
      opacity: 1,
      color: "#00060A",
      borderRadius: "4px",
      "& fieldset": {
        borderRadius: "8px",
        height: "7vh",
      },
    },
  },
});

const LoginButton = styled(Button)({
  backgroundColor: "#795548",
  color: "white",
  "&:hover": {
    backgroundColor: "#5d4037",
  },
  marginTop: "1rem",
});

// Custom styled IconButton to reduce its size
const SmallIconButton = styled(IconButton)({
  fontSize: "1rem", // Adjust font size if needed
  padding: "5px", // Adjust padding to reduce button size
  "& svg": {
    fontSize: "0.8rem", // Adjust icon size
  },
});


const ForgotPassword = styled(Typography)({
  marginTop: "1rem",
  textAlign: "center",
});

const Login = ({ setUser }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleClickShowPassword = () => setShowPassword(!showPassword);

  const handleLogin = (event) => {
    event.preventDefault();
    const user = credentials.find(
      (cred) => cred.email === email && cred.password === password
    );
    if (user) {
      setUser(user);
      localStorage.setItem("userEmail", user.email);
      localStorage.setItem("userName", user.name);
      localStorage.setItem("userRole", user.role);
      navigate("/dashboard");
    } else {
      alert("Invalid username or password");
    }
  };

  return (
    <Grid
      container
      sx={{ backgroundColor: "#F2EEED", width: "100vw", height: "100vh" }}
    >
      <Grid item xs={12} md={6}>
        <ImageContainer>
          <LogoContainer>
            <img src={Logo} alt="Logo" width="100%" height="100%" />
          </LogoContainer>
        </ImageContainer>
      </Grid>
      <Grid
        item
        xs={12}
        md={6}
        container
        justifyContent="center"
        alignItems="center"
        sx={{
          "& .MuiInputBase-root": {
            marginBottom: "1rem",
            borderRadius: "8px", //To set the background white to the username and password
            height: "6.8vh", //This increases the text field borders i.e., username and passwords fields
            background: "white",
          },
        }}
      >
        <LoginForm>
          <Typography
            variant="h6"
            // gutterbottom="true"
            align="center"
            sx={{ marginBottom: 6, fontWeight: "bold",color:'black' }}
          >
            Login
          </Typography>
          <Typography variant="subtitle1" align="left" sx={{ fontSize: "80%", color:'black' }}>
            Username
          </Typography>
          <LoginTextField
            variant="outlined"
            sx={{ mb: 2, width: '100%', '& .MuiInputBase-input': { height: '30px', padding: '6px' }, borderRadius: "8px", }}
            fullWidth
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Typography variant="subtitle1" align="left" sx={{ fontSize: "80%",color:'black' }}>
            Password
          </Typography>
          <LoginTextField
            // variant="outlined"
            type={showPassword ? "text" : "password"}
            sx={{ mb: 2, width: '100%', '& .MuiInputBase-input': { height: '30px', padding: '6px' }, marginBottom: "-1rem", borderRadius: "8px", }}
            fullWidth
           
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <SmallIconButton onClick={handleClickShowPassword}>
                    {showPassword ? <Visibility /> : <VisibilityOff />}
                  </SmallIconButton>
                </InputAdornment>
              ),
            }}
          />

          <FormControlLabel
            control={<CustomCheckbox />}
            label={
              <Typography sx={{ fontSize: "10px", fontWeight: "bold",color:'black' }}>
                Remember me
              </Typography>
            }
            sx={{ marginTop: 0, paddingLeft: "0.3rem" }}
          />

          <LoginButton
            variant="contained"
            fullWidth
            onClick={handleLogin}
            sx={{ textTransform: "none" }}
          >
            Login
          </LoginButton>
          <ForgotPassword>
            <a
              href="#"
              style={{ color: "#795548", textDecoration: "underline" }}
            >
              Forgot Password?
            </a>
          </ForgotPassword>
        </LoginForm>
      </Grid>
    </Grid>
  );
};

export default Login;
