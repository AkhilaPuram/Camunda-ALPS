import React, { useState } from "react";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  CircularProgress,
  Typography,
  Paper,
} from "@mui/material";
import { styled } from "@mui/system";

const CustomTableCell = styled(TableCell)(({ theme }) => ({
  backgroundColor: theme.palette.grey[200],
  fontWeight: "bold",
  fontSize: "1.2rem",
}));

const CustomTableRow = styled(TableRow)(({ theme }) => ({
  "& th": {
    fontWeight: "bold",
    fontSize: "1rem",
  },
  "&:hover": {
    backgroundColor: "#F2EEED",
  },
}));

const CircularProgressWithLabel = (props) => {
  return (
    <Box position="relative" display="inline-flex" width={props.size} height={props.size}>
      <CircularProgress variant="determinate" {...props} size={props.size} />
      <Box
        top={0}
        left={0}
        bottom={0}
        right={0}
        position="absolute"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Typography
          variant="caption"
          component="div"
          color="textSecondary"
          style={{ fontSize: props.size * 0.2 }}
        >{`${Math.round(props.value)}%`}</Typography>
      </Box>
    </Box>
  );
};

const EvaluationTable = () => {
  const [personalScore, setPersonalScore] = useState(null);
  const [licenseScore, setLicenseScore] = useState(null);
  const [healthScore, setHealthScore] = useState(null);

  const handleScoreChange = (setScore) => (event) => {
    const value = event.target.value === "yes" ? 100 : event.target.value === "no" ? 0 : null;
    setScore(value);
  };

  const weightedScorePersonal = (personalScore ?? 0) * 0.5;
  const weightedScoreLicense = (licenseScore ?? 0) * 0.3;
  const weightedScoreHealth = (healthScore ?? 0) * 0.2;
  const totalWeightedScore = weightedScorePersonal + weightedScoreLicense + weightedScoreHealth;

  let recommendation = "Approve";
  let progressColor = "green";
  if (totalWeightedScore < 15) {
    recommendation = "Rejected";
    progressColor = "red";
  } else if (totalWeightedScore < 50) {
    recommendation = "Tentative";
    progressColor = "orange";
  }

  return (
    <Box display="flex" justifyContent="center" alignItems="center" minHeight="50vh">
      <Paper sx={{ width: "95%", height: "auto", padding: "20px" }}>
        <Typography variant="h5" fontWeight={"bold"} mb={2}>
          Evaluate case
        </Typography>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <CustomTableCell sx={{ textAlign: "center" }}>Evaluation criteria</CustomTableCell>
                <CustomTableCell sx={{ textAlign: "center" }}>Maximum score</CustomTableCell>
                <CustomTableCell sx={{ textAlign: "center" }}>Weightage</CustomTableCell>
                <CustomTableCell sx={{ textAlign: "center" }}>Weighted score</CustomTableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {[
                {
                  criteria: "Personal Behaviour",
                  score: personalScore,
                  setScore: setPersonalScore,
                  maxScore: 100,
                  weightage: 50,
                  weightedScore: weightedScorePersonal,
                },
                {
                  criteria: "R- License Number",
                  score: licenseScore,
                  setScore: setLicenseScore,
                  maxScore: 100,
                  weightage: 30,
                  weightedScore: weightedScoreLicense,
                },
                {
                  criteria: "Current Health Status",
                  score: healthScore,
                  setScore: setHealthScore,
                  maxScore: 100,
                  weightage: 20,
                  weightedScore: weightedScoreHealth,
                },
              ].map((row, index) => (
                <CustomTableRow key={index} style={{ backgroundColor: index === 2 ? "#E8F0FE" : "inherit" }}>
                  <TableCell sx={{ textAlign: "center" }}>
                    {row.criteria}
                    <Box mt={1} display="flex" justifyContent="center">
                      <FormControl component="fieldset">
                        <RadioGroup
                          row
                          value={row.score === 100 ? "yes" : row.score === 0 ? "no" : null}
                          onChange={handleScoreChange(row.setScore)}
                        >
                          <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                          <FormControlLabel value="no" control={<Radio />} label="No" />
                        </RadioGroup>
                      </FormControl>
                    </Box>
                  </TableCell>
                  <TableCell sx={{ textAlign: "center" }}>{row.maxScore}</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>{row.weightage}</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>{row.weightedScore.toFixed(1)}</TableCell>
                </CustomTableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <Box display="flex" justifyContent="space-between" alignItems="center" paddingTop={"20px"}>
          <Box>
            <Typography variant="h8" fontWeight={"bold"}>
              System recommendation
            </Typography>
            <Typography variant="h6" fontWeight={"bold"} color="black">
              {recommendation}
            </Typography>
          </Box>
        </Box>
        <Box align="center">
          <CircularProgressWithLabel value={totalWeightedScore} size={150} style={{ color: progressColor }} />
        </Box>
      </Paper>
    </Box>
  );
};

export default EvaluationTable;
