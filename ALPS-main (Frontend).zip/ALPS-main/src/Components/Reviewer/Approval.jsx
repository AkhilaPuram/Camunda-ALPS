import React, { useState, useEffect, useContext } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  TextField, Button, Typography, Paper, FormControl, 
  FormLabel, RadioGroup, FormControlLabel, Radio, Box, Grid 
} from '@mui/material';
import { styled } from '@mui/system';
import axios from 'axios';
import Details from "../ApplicationRequest/details";
import { SnackContext } from '../GlobalComponent/SnackProvider'; // Import SnackContext

const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#c55a3321",
  ...theme.typography.body2,
  padding: "8px 30px", 
  color: "#795548",
  fontWeight: 600,
  fontSize: "0.8rem", 
  borderRadius: "2em",
  border: "1px solid #795548",
  "&:hover": {
    backgroundColor: "#795548",
    color: "white",
  },
}));

const ApprovalForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [courtCases, setCourtCases] = useState('');
  const [notes, setNotes] = useState('');
  const [caseDetails, setCaseDetails] = useState({});
  const [inspectionCase, setInspectionCase] = useState('');
  const license_Id = location.state?.license_Id;
  const { setSnack } = useContext(SnackContext); // Use SnackContext

  useEffect(() => {
    const getReviewCaseDetails = async () => {
      if (license_Id) {
        try {
          const response = await axios.get(`${import.meta.env.VITE_BASE_URL}/alps/license/${license_Id}`);
          const programDetails = response?.data?.programDetails;
          setCaseDetails({
            application_for: programDetails?.application_for,
            duration: programDetails?.duration,
            application_startdate: programDetails?.application_startdate,
            status: programDetails?.status,
            category: programDetails?.category,
            application_fee: programDetails?.application_fee,
            subcategory: programDetails?.subcategory,
          });
        } catch (error) {
          console.error("Error fetching case details:", error);
        }
      }
    };
    getReviewCaseDetails();
  }, [license_Id]);

  useEffect(() => {
    setCourtCases("I'm sorry, but I couldn't find any specific information about court cases, summons, or penalties related to Santino in the media. It's possible that this information may not be publicly available or may not have been widely reported. It's always a good idea to consult official sources or legal professionals for accurate and up-to-date information on specific cases.");
  }, []);

  const handleReject = () => {
    setSnack({
      open: true,
      message: 'The case has been Rejected',
      severity: 'error',
    });
    navigate('/dashboard');
  };

  const handleApprove = async () => {
    if (license_Id) {
      await axios.post(`${import.meta.env.VITE_BASE_URL}/alps/submitApprove/${license_Id}`);
      setSnack({
        open: true,
        message: 'The case has been Approved',
        severity: 'success',
      });
      navigate('/dashboard');
    }
  };

  return (
    <Box sx={{ px: 10 }}>
      <Box sx={{ m: 2, mt: 12, pl: 20 }}>
        <Paper
          elevation={3}
          sx={{
            width: '130%',
            margin: '20px 10px 10px',
            padding: '10px',
            marginLeft: '-20%',
          }}
        >
          <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', paddingBottom: '10px' }}>
            Approval
          </Typography>
          <TextField
            label="Court cases / Summons / Penalties (AI Powered)"
            value={courtCases}
            onChange={(e) => setCourtCases(e.target.value)}
            multiline
            rows={4}
            variant="outlined"
            fullWidth
            margin="normal"
          />
          <FormLabel component="legend" sx={{ marginTop: '20px' }}>Notes</FormLabel>
          <TextField
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            multiline
            rows={4}
            variant="outlined"
            fullWidth
            margin="normal"
          />
          <FormControl component="fieldset" sx={{ marginTop: '20px' }}>
            <FormLabel component="legend">Would you like to create Inspection case?</FormLabel>
            <RadioGroup
              aria-label="inspection-case"
              name="inspection-case"
              value={inspectionCase}
              onChange={(e) => setInspectionCase(e.target.value)}
              row
            >
              <FormControlLabel value="yes" control={<Radio />} label="Yes" />
              <FormControlLabel value="no" control={<Radio />} label="No" />
            </RadioGroup>
          </FormControl>
        </Paper>
      </Box>
      <Grid container sx={{ pt: 3, pl: 5, pl: 1 }}>
        <Grid item xs={6} sx={{ paddingLeft: '0px', pr: 45 }}>
          <StyledButton color="inherit" onClick={() => navigate('/dashboard')}>
            Back
          </StyledButton>
        </Grid>
        <Grid item xs={6} container justifyContent="flex-end"  columnGap={1}>
          <StyledButton onClick={handleReject}>
            Reject
          </StyledButton>
          <StyledButton onClick={handleApprove}>
            Approve
          </StyledButton>
        </Grid>
      </Grid>
      <Grid container px={0}>
        <Details programDetails={caseDetails} />
      </Grid>
    </Box>
  );
};

export default ApprovalForm;
