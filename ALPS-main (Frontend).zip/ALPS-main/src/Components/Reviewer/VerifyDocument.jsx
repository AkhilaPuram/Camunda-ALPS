import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TextField,
} from "@mui/material";
import { styled } from "@mui/system";
import { grey } from "@mui/material/colors";
import axios from 'axios';

const StyledTableHead = styled(TableHead)({
  backgroundColor: grey[200],
  "& th": {
    fontWeight: "bold",
  },
});

const DocumentVerification = ({ licenseId }) => { // Use the prop licenseId instead of license_Id
  const [documents, setDocuments] = useState([]);

  // Fetch documents from API
  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const response = await axios.get(`${import.meta.env.VITE_BASE_URL}/alps/getdocumentintakedetails/${licenseId}`);
        setDocuments(response.data); // Use response data directly
      } catch (error) {
        console.error("Error fetching documents:", error);
      }
    };

    if (licenseId) {
      fetchDocuments(); // Fetch documents only if licenseId is available
    }
  }, [licenseId]);

  return (
    <Paper>
      <Container sx={{ py: 3 }}>
        <Typography
          variant="h5"
          gutterBottom
          fontWeight="bold"
          marginBottom={"25px"}
        >
          Verify Document
        </Typography>
        <TableContainer component={Paper}>
          <Table>
            <StyledTableHead>
              <TableRow>
                <TableCell>Document Type</TableCell>
                <TableCell>Name</TableCell>
                <TableCell>Comments</TableCell>
              </TableRow>
            </StyledTableHead>
            <TableBody>
              {documents.map((doc, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Typography variant="subtitle1" fontWeight="bold">
                      {doc.document_type}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{doc.name}</Typography>
                  </TableCell>
                  <TableCell>
                    <TextField
                      variant="outlined"
                      fullWidth
                      multiline
                      rows={3}
                      placeholder="Comments"
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Container>
    </Paper>
  );
};

export default DocumentVerification;
