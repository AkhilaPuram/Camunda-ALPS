import * as React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Box, Grid, Typography } from '@mui/material';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import Details from "../ApplicationRequest/details";
import VerifyDocument from './VerifyDocument';
import ReviewCheckList from './ReviewCheckList';
import EvaluateFile from './EvaluateFile';
import axios from 'axios';
import { SnackContext } from "../GlobalComponent/SnackProvider"; // Import SnackContext

// Define steps
const steps = ['Verify Document', 'Review CheckList', 'Evaluate Files'];

const StyledButton = styled(Button)(({ theme }) => ({
    backgroundColor: "#c55a3321",
    ...theme.typography.body2,
    padding: "8px 30px", // Increased padding
    textAlign: "center",
    color: "#795548",
    fontWeight: 600,
    fontSize: "0.8rem", // Increased font size
    borderRadius: "2em",
    border: "1px solid #795548",
    "&:hover": {
      backgroundColor: "#795548",
      color: "White",
    },
}));

const SaveButton = styled(StyledButton)(({ theme }) => ({
    backgroundColor: "#d3d3d3",
    color: "#000",
    border: "1px solid #ccc",
    '&:hover': {
        backgroundColor: "#bbb",
        color: "#000",
    },
}));

// Custom Step styled component
const CustomStep = styled(Step)(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
}));

// Custom StepLabel styled component
const CustomStepLabel = styled(StepLabel)(({ theme }) => ({
    display: 'flex',
    flexDirection: 'column',
    color: "#795548",
    alignItems: 'center',
    marginTop: theme.spacing(2), // Increased space between index and label
    '& .MuiStepIcon-root': {
        marginBottom: theme.spacing(1), // Space between icon and label
    },
}));

export default function HorizontalLinearStepper() {
    const [activeStep, setActiveStep] = React.useState(0);
    const [skipped, setSkipped] = React.useState(new Set());
    const navigate = useNavigate();
    const location = useLocation();
    const license_Id = location.state?.license_Id;
    const [caseDetails, setCaseDetails] = React.useState({});
    const { setSnack } = React.useContext(SnackContext); // Use SnackContext

    const isStepOptional = (step) => step === 1;
    const isStepSkipped = (step) => skipped.has(step);

    React.useEffect(() => {
        const getReviewCaseDetails = async () => {
            try {
                const response = await axios({
                    method: 'get',
                    url: `${import.meta.env.VITE_BASE_URL}/alps/license/${license_Id}`
                });
                console.log(response?.data);
                setCaseDetails({
                    application_for: response?.data?.programDetails?.application_for,
                    duration: response?.data?.programDetails?.duration,
                    application_startdate: response?.data?.programDetails?.application_startdate,
                    status: response?.data?.programDetails?.status,
                    category: response?.data?.programDetails?.category,
                    application_fee: response?.data?.programDetails?.application_fee,
                    subcategory: response?.data?.programDetails?.subcategory,
                });
            } catch (error) {
                console.error("Error fetching case details:", error);
            }
        };
        getReviewCaseDetails();
    }, [license_Id]);

    const handleNext = async () => {
        let newSkipped = skipped;
        if (isStepSkipped(activeStep)) {
            newSkipped = new Set(newSkipped.values());
            newSkipped.delete(activeStep);
        }
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        setSkipped(newSkipped);

        if (activeStep === steps.length - 1) {
            try{
            await axios({
                method: 'post',
                url: `${import.meta.env.VITE_BASE_URL}/alps/submitreview/${license_Id}`,
                data: {}
            });
            setSnack({
                open: true,
                message: "The case has been moved to the Approver",
                severity: "success",
            });
        } catch (error) {
            console.error("Error submitting the review:", error);
            setSnack({
                open: true,
                message: "An error occurred during submission. Please try again.",
                severity: "error",
            });
        } finally {
            navigate('/dashboard');
        }
        }
    };

    const handleBack = () => {
        if (activeStep === 0) {
            navigate('/dashboard');
        } else {
            setActiveStep((prevActiveStep) => prevActiveStep - 1);
        }
    };

    const handleSave = () => {
        // Here you can add any save logic if needed
        setSnack({
            open: true,
            message: "The data has been saved Successfully",
            severity: "success",
        });
    };

    const handleReset = () => {
        setActiveStep(0);
    };

    return (
        <Box sx={{ width: '100%', m: 2, mt: 10, px: 10 }}> {/* Added margin-top */}
            <Stepper activeStep={activeStep} sx={{ px: 20 }}>
                {steps.map((label, index) => {
                    const stepProps = {}; 
                    const labelProps = {};
                    if (isStepOptional(index)) {
                        labelProps.optional = (
                            <Typography variant="caption"></Typography>
                        );
                    }
                    if (isStepSkipped(index)) {
                        stepProps.completed = false;
                    }
                    return (
                        <CustomStep key={label} {...stepProps}>
                            <CustomStepLabel {...labelProps}>{label}</CustomStepLabel>
                        </CustomStep>
                    );
                })}
            </Stepper>
            <React.Fragment>
                <Box sx={{ pt: 5, px: 2 }}>
                    {activeStep === 0 && <VerifyDocument licenseId={license_Id}/>}
                    {activeStep === 1 && <ReviewCheckList />}
                    {activeStep === 2 && <EvaluateFile />}
                </Box> 
                <Grid
                    container
                    justifyContent='space-between'
                    sx={{ pt: 4, px: 5 }}
                >
                    <Grid item xs={6}>
                        <StyledButton
                            color="inherit"
                            onClick={handleBack}
                        >
                            Back
                        </StyledButton>
                    </Grid>
                    <Grid item xs={6} container columnGap={2} justifyContent='flex-end'>
                        <StyledButton onClick={handleSave}>
                            Save
                        </StyledButton>
                        <StyledButton onClick={handleNext}>
                            {activeStep === steps.length - 1 ? "Submit" : "Next"}
                        </StyledButton>
                    </Grid>
                </Grid>
            </React.Fragment>
            <Details programDetails={caseDetails}/>
        </Box>
    );
}
