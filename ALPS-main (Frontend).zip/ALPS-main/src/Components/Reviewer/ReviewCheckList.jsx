

import React from "react";
import {
  Container,
  Typography,
  Grid,
  Checkbox,
  Paper,
  Box,
} from "@mui/material";
import { styled } from "@mui/system";
import ChecklistIcon from "@mui/icons-material/Checklist";

const ChecklistItem = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  border: `1px solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(1),
  width: "100%",
  maxWidth: "300px",
  margin: theme.spacing(1),
}));

const ReviewChecklist = () => {
  return (
    <Box
    display="flex"
    justifyContent="center"
    alignItems="center"
    
    paddingRight={30}
    width="100%"
  >
    <Container>
      <Paper
        sx={{
          margin: "auto",
          padding: 4,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "120%",
          
        }}
      >
        <Typography
          variant="h5"
          gutterBottom
          fontWeight="bold"
          sx={{ paddingBottom: 2 }}
          align="Left"
          
        >
          Review checklist
        </Typography>

        <Grid container alignItems="center" spacing={1}>
          <Grid item>
            <ChecklistIcon
              style={{
                fontSize: 30,
              }}
            />
          </Grid>
          <Grid item>
            <Typography variant="h5" fontWeight="bold">
              Checklist
            </Typography>
          </Grid>
        </Grid>

        <Grid container spacing={2} sx={{ marginTop: 2 }}>
          <Grid item>
            <ChecklistItem>
              <Typography variant="body1">R-License Number</Typography>
              <Checkbox />
            </ChecklistItem>
          </Grid>
          <Grid item>
            <ChecklistItem>
              <Typography variant="body1">Trainer Number</Typography>
              <Checkbox />
            </ChecklistItem>
          </Grid>
          <Grid item>
            <ChecklistItem>
              <Typography variant="body1">NIN</Typography>
              <Checkbox />
            </ChecklistItem>
          </Grid>
        </Grid>
      </Paper>
    </Container>
    </Box>
  );
};

export default ReviewChecklist;
