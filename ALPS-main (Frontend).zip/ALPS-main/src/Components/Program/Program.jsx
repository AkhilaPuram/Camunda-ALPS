import React, { useEffect, useState } from "react";
import { Paper, Box, Button, Stack, Grid, styled, FormControl, Select, MenuItem, Typography } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import CombinedForm from "../PersonalDetails/Accredential&Native.jsx";
import ProgramDetails from "../ProgramDetails/ProgramDetails.jsx";
import Details from "../ApplicationRequest/details.jsx";

const Program = () => {
    const [sub, setSub] = useState("");
    const [main, setMain] = useState("");
    const [idx, setIndex] = useState(null);
    const [subCategorytypeData, setSubcategorytypeData] = useState([]);
    const [display, setDisplay] = useState(true);
    const navigate = useNavigate(); // useNavigate instead of useHistory

    useEffect(() => {
        if (main === "License" && (sub === "Hunting" || sub === "FireArms")) {
            fetchSubcategorytypeData();
        }
    }, [main, sub]);

    const Item = styled(Box)(({ theme }) => ({
        backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: "center",
        color: theme.palette.text.primary,
    }));

    const StyledPaper = styled(Paper)(({ theme }) => ({
        padding: theme.spacing(2),
        marginTop: theme.spacing(2),
        backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
        ...theme.typography.body2,
    }));

    const StyledButton = styled(Button)(({ theme }) => ({
        backgroundColor: "#c55a3321",
        ...theme.typography.body2,
        padding: "12px",
        textAlign: "center",
        color: "#795548",
        fontWeight: 600,
        width: "8vw",
        borderRadius: "2em",
        border: "1px solid #795548",
        '&:hover': {
              backgroundColor: "#795548",
              color: "White",
          },
      }));

    const ItemOne = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
        ...theme.typography.body2,
        padding: theme.spacing(2),
        textAlign: "center",
    }));

    const fetchSubcategorytypeData = async () => {
        try {
            // Determine the correct value to pass based on the selected subcategory
            let subCategoryValue = sub === "Hunting" ? 2 : sub === "FireArms" ? 7 : null;

            if (subCategoryValue) {
                const subcategorytype = await axios({
                    method: 'get',
                    url: `${import.meta.env.VITE_BASE_URL}/alps/subsubcategoryname/${subCategoryValue}`
                })
                setSubcategorytypeData(subcategorytype?.data);
            }
        } catch (err) {
            console.log(err.message);
        }
    };

    const handleCreateClick = () => {
        setDisplay(false);
    };

    const handleBackClick = () => {
        setDisplay(true);
    };

    const handleItemClick = (option) => {
        navigate(`/program-details`, {state: {subCategoryOption:option }}); // use navigate for routing
    };

    const handleCancelClick = () => {
        navigate("/Dashboard");
    };

    return (
        <>
            {display ? (
                <Stack spacing={4} alignItems="center" m={2} mt={10} width='100%'>
                    <Paper
                        sx={{
                            width: "100%",
                            p: 2,
                            border: "1px solid #80808040",
                            borderRadius: "0.3em",
                        }}
                    >
                       
                            <Stack direction="row" justifyContent={"space-between"}>
                                <Item sx={{ fontWeight: 600, fontSize:"20px" }}>Select Program</Item>
                            </Stack>
                        
                        <Grid container justifyContent={"start"} padding="0.5em">
                            <Grid item xs={12} lg={6}>
                                <Stack direction="row" sx={{ margin: "auto 0", paddingRight: "1em", fontSize:"125%" }}>
                                    <strong style={{ margin: "auto 0", fontSize: '16px' }}>Category</strong>
                                    <Item sx={{ minWidth: "150px" }}>
                                        <FormControl fullWidth size="small" sx = {{paddingLeft:"1.5em"}}>
                                            <Select
                                                value={main}
                                                onChange={(e) => setMain(e.target.value)}
                                            >
                                                <MenuItem value={"Program"}>Program</MenuItem>
                                                <MenuItem value={"License"}>License</MenuItem>
                                                <MenuItem value={"Grants"}>Grants</MenuItem>
        
                                            </Select>
                                        </FormControl>
                                    </Item>
                                    <strong style={{ margin: "auto 0", paddingLeft:300,fontSize: '16px' }}>SubCategory</strong>
                                    <Item sx={{ minWidth: "150px" }}>
                                        <FormControl fullWidth size="small" sx = {{paddingLeft:"1.5em"}}>
                                            <Select
                                                value={sub}
                                                onChange={(e) => setSub(e.target.value)}
                                            >
                                                <MenuItem value={"Professional"}>Professional</MenuItem>
                                                <MenuItem value={"Fishery"}>Fishery</MenuItem>
                                                <MenuItem value={"Pesticides"}>Pesticides</MenuItem>
                                                <MenuItem value={"Motor vehicles"}>Motor Vehicles</MenuItem>
                                                <MenuItem value={"Recreational"}>Recreational</MenuItem>
                                                <MenuItem value={"Hunting"}>Hunting</MenuItem>
                                                <MenuItem value={"FireArms"}>FireArms</MenuItem>
                                            </Select>
                                        </FormControl>
                                    </Item>
                                </Stack>
                            </Grid>
                        </Grid>
                        {main === "License" && (sub === "Hunting" || sub === "FireArms") && (
                            <Grid>
                                <strong style={{ margin: "auto 0", paddingLeft: '8px', fontSize:"110%",   }}>Program</strong>
                                <Grid container spacing={3} padding={1}>
                                    {subCategorytypeData?.subsubcategory?.map((option, index) => (
                                        <Grid item xs={12} sm={6} md={3} key={index}>
                                            <ItemOne
                                                sx={{
                                                    backgroundColor: index === idx ? "#795548" : "",
                                                    color: index === idx ? "#ffffff" : "black",
                                                    '&:hover': {
                                                        backgroundColor: "#795548",
                                                        color: "white",
                                                    },
                                                }}
                                                onClick={() => handleItemClick(option)}
                                            >
                                                {option}
                                            </ItemOne>
                                        </Grid>
                                    ))}
                                </Grid>
                                <Grid item container justifyContent={"space-between"} ml={1} mt={2}>
                                    <Stack direction={"row"}>
                                        <StyledButton onClick={handleCancelClick}>Cancel</StyledButton>
                                    </Stack>
                                </Grid>
                            </Grid>
                        )}
                    </Paper>


                </Stack>
            ) : (
                <CombinedForm onBack={handleBackClick} />
            )}
        </>
    );
};

export default Program;
