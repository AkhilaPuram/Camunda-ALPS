import React, { useState } from 'react';
import { Tabs, Tab, Box, Typography, Paper, Grid } from '@mui/material';
import { styled } from '@mui/system';

// Custom styled tab component
const StyledTab = styled(Tab)(({ theme }) => ({
  backgroundColor: "#c55a3321",
  ...theme.typography.body2,
  padding: "1em",
  textAlign: "center",
  fontWeight: "bold",
  "&:hover": {
    backgroundColor: "#8D6E63",
    transition: "0.3s",
    borderBottom: "2px solid #795548",
    color: "white",
  },
  "&.Mui-selected": {
    color: "white",
    backgroundColor: "#795548",
  },
}));

// Custom styled tabs container
const CustomTabsContainer = styled(Tabs)({
  "& .MuiTabs-indicator": {
    display: 'none',
  },
});

// Component to display the applicant table
const ApplicantTable = ({ programDetails }) => (
  <Grid container spacing={2} component={Paper} sx={{ padding: 2 }}>
    <Grid item xs={12}>
      <Typography variant="h6">Applicant</Typography>
    </Grid>
    {/* <Grid item xs={6}>
      <Typography>Name: {programDetails?.application_for || 'N/A'}</Typography>
    </Grid> */}
    <Grid item xs={6}>
      <Typography>Applicant ID: --</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Date Issued: -- </Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Status: {programDetails?.status ? programDetails?.status : 'Open'}</Typography>
    </Grid>
  </Grid>
);

// Component to display the program details
const ProgramGrid = ({ programDetails }) => (
  <Grid container spacing={2} component={Paper} sx={{ padding: 2 }}>
    <Grid item xs={12}>
      <Typography variant="h6">Program Details</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Program: {programDetails?.program_name || 'N/A'}</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Duration: {programDetails?.duration || 'N/A'}</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Category: {programDetails?.category || 'N/A'}</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Fee: {programDetails?.application_fee || 'N/A'}</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Sub category: {programDetails?.subcategory || 'N/A'}</Typography>
    </Grid>
    <Grid item xs={6}>
      <Typography>Compliance required: Yes</Typography>
    </Grid>
  </Grid>
);

// Main CustomTabs component
function CustomTabs({ programDetails }) {
  const [activeTab, setActiveTab] = useState(0);

  const handleChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  console.log('Program Details:', programDetails);

  return (
    <Paper sx={{ marginTop: 8, height: '313px', width:"1000px" }}> 
      <Box sx={{ width: '100%', height: '300px' }}> 
        <Typography variant="h6" fontWeight="bold" padding={2}>Details</Typography>
        <CustomTabsContainer value={activeTab} onChange={handleChange} aria-label="details tabs">
          <StyledTab label="PROGRAM" />
          <StyledTab label="APPLICANT" />
        </CustomTabsContainer><Box>
        <Box sx={{ padding: 2, height: 'calc(100% - 48px)' }}> 
          {activeTab === 0 && <ProgramGrid programDetails={programDetails} />}
          </Box>
          <Box sx={{ padding: 2, height: 'calc(100% - 35px)' }}>
          {activeTab === 1 && <ApplicantTable programDetails={programDetails} />}
        </Box>
        </Box>
      </Box>
    </Paper>
  );
}

export default CustomTabs;
