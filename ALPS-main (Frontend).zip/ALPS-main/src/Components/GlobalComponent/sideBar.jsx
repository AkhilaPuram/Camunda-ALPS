
import {
  Avatar,
  Box,
  IconButton,
  Typography,
  styled,
  Popper,
  List,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Collapse,
  Grid,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import HomeIcon from "@mui/icons-material/Home";
import NotificationsIcon from "@mui/icons-material/Notifications";
import WorkIcon from "@mui/icons-material/Work";
import LogoutIcon from "@mui/icons-material/Logout";
import CreateIcon from "@mui/icons-material/Add";

const TopArrowRight = styled("div")({
  position: "absolute",
  top: "50%",
  left: "50%",
  width: "4px",
  height: "20px",
  backgroundColor: "#795548",
  transform: "translate(-50%, -50%) rotate(15deg)",
  transformOrigin: "0 0",
  borderRadius: "2px 2px 0 0",
});

const BottomArrowRight = styled("div")({
  position: "absolute",
  top: "85%",
  left: "50%",
  width: "4px",
  height: "20px",
  backgroundColor: "#795548",
  transform: "translate(-50%, -50%) rotate(-15deg)",
  transformOrigin: "0 100%",
  borderRadius: "0 0 2px 2px",
});

const TopArrowLeft = styled("div")({
  position: "absolute",
  top: "50%",
  left: "50%",
  width: "4px",
  height: "20px",
  backgroundColor: "#795548",
  transform: "translate(-50%, -50%) rotate(-15deg)",
  transformOrigin: "0 0",
  borderRadius: "2px 2px 0 0",
});

const BottomArrowLeft = styled("div")({
  position: "absolute",
  top: "85%",
  left: "50%",
  width: "4px",
  height: "20px",
  backgroundColor: "#795548",
  transform: "translate(-50%, -50%) rotate(15deg)",
  transformOrigin: "0 100%",
  borderRadius: "0 0 2px 2px",
});

const SideBar = ({ setIsSidebarCollapsed, setUser }) => {
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [openCreate, setOpenCreate] = useState(false);
  const navigate = useNavigate();
  const [isHovered, setIsHovered] = useState(false);
  const [openLogout, setOpenLogout] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);

  const topMenuItems = [
    {
      text: "Application Request",
      icon: <CreateIcon />,
      onClick: () => navigate(`/create`),
    },
    {
      text: "Home",
      icon: <HomeIcon />,
      onClick: () => navigate(`/dashboard`),
    },
    {
      text: "My Work",
      icon: <WorkIcon />,
      onClick: () => console.log("My Work clicked"),
    },
  ];

  const bottomMenuItems = [
    {
      text: "Notifications",
      icon: <NotificationsIcon />,
      onClick: () => console.log("Notifications clicked"),
    },
  ];

  useEffect(() => {
    setIsSidebarCollapsed(isCollapsed);
  }, [isCollapsed]);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const handleMouseClick = () => {
    setIsHovered(false);
    setIsCollapsed(!isCollapsed);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    setOpenLogout(!openLogout);
  };

  const signOut = () => {
    setOpenLogout(!openLogout);
    localStorage.clear();
    setUser({});
    navigate("/");
  };

  const handleCreateClick = () => {
    setOpenCreate(!openCreate);
  };

  return (
    <Box
      sx={{
        backgroundColor: "#F2EEED",
        width: isCollapsed ? 60 : 205,
        position: "fixed",
        top: 0,
        left: 0,
        height: "92vh",
        overflowY: "auto",
        borderTopRightRadius: "20px",
        zIndex: 1000,
        marginTop: 8,
      }}
    >
      <Box
        display="flex"
        flexDirection="column"
        justifyContent="space-between"
        height="100%"
        paddingTop={"1px"}
      >
        <List>
          <Collapse in={openCreate} timeout="auto" unmountOnExit></Collapse>
          {topMenuItems.map((item, index) => (
            <ListItemButton
              sx={{
                color: "#795548",
                "&:hover": {
                  backgroundColor: "#D7CCC8",
                },
                "& .MuiListItemIcon-root": {
                  minWidth: 40,
                },
                "& .MuiSvgIcon-root": {
                  fontSize: 18,
                },
                "& .MuiListItemText-primary": {
                  fontSize: 12,
                },
              }}
              key={index}
              onClick={item.onClick}
            >
              <ListItemIcon sx={{ color: "#795548" }}>
                {item.icon}
              </ListItemIcon>
              {!isCollapsed && <ListItemText primary={item.text} />}
            </ListItemButton>
          ))}
        </List>
        <Box flexGrow={1} />
        <List>
          {bottomMenuItems.map((item, index) => (
            <ListItemButton
              sx={{
                color: "#795548",
                "&:hover": {
                  backgroundColor: "#D7CCC8",
                },
                "& .MuiListItemIcon-root": {
                  minWidth: 40,
                },
                "& .MuiSvgIcon-root": {
                  fontSize: 18,
                },
                "& .MuiListItemText-primary": {
                  fontSize: 12,
                },
              }}
              key={index}
              onClick={item.onClick}
            >
              <ListItemIcon sx={{ color: "#795548" }}>
                {item.icon}
              </ListItemIcon>
              {!isCollapsed && <ListItemText primary={item.text} />}
            </ListItemButton>
          ))}
          <ListItemButton
            sx={{
              color: "#795548",
              "&:hover": {
                backgroundColor: "#D7CCC8",
              },
              "& .MuiListItemIcon-root": {
                minWidth: 40,
              },
              "& .MuiSvgIcon-root": {
                fontSize: 28,
              },
              "& .MuiListItemText-primary": {
                fontSize: 12,
              },
            }}
            onClick={handleClick}
          >
            <Avatar
              sx={{
                width: 20,
                height: 20,
                marginRight: "20px",
                color: "#795548",
              }}
            />
            {!isCollapsed && <ListItemText primary="User Profile" />}
          </ListItemButton>
        </List>
      </Box>
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        sx={{
          position: "absolute",
          top: "50%",
          left: isCollapsed ? 0 : 145,
          width: 60,
          height: 60,
          cursor: "pointer",
          transition: "left 0.3s",
        }}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleMouseClick}
      >
        <Box
          sx={{
            position: "relative",
            width: "20px",
            height: "40px",
            marginLeft: "45px",
          }}
        >
          {!isHovered && (
            <Box
              sx={{
                width: "2px",
                height: "24px",
                backgroundColor: "#795548",
                borderRadius: "2px",
              }}
            />
          )}
          {isHovered && isCollapsed && (
            <>
              <TopArrowLeft />
              <BottomArrowLeft />
            </>
          )}
          {isHovered && !isCollapsed && (
            <>
              <TopArrowRight />
              <BottomArrowRight />
            </>
          )}
        </Box>
      </Grid>
      <Popper
        open={openLogout}
        anchorEl={anchorEl}
        placement="right"
        modifiers={[
          {
            name: "offset",
            options: {
              offset: [0, 10],
            },
          },
        ]}
      >
        <Box
          sx={{
            background: `#FFFFFF 0% 0% no-repeat padding-box`,
            boxShadow: `0px 3px 8px #00000029`,
            borderRadius: `2px 10px 10px 2px`,
            opacity: 1,
            px: 2,
            py: 0.5,
          }}
          display="flex"
          alignItems="center"
          columnGap={6}
        >
          <Typography variant="h6">
            {localStorage.getItem("userName")}
          </Typography>
          <IconButton onClick={signOut}>
            <LogoutIcon />
          </IconButton>
        </Box>
      </Popper>
    </Box>
  );
};

export default SideBar;
