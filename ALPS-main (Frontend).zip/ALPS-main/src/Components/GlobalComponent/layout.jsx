import { Box } from "@mui/material";
import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import TopBar from "./TopBar";
import SideBar from "./sideBar"; // Import Sidebar component

const Layout = ({ user, setUser }) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);

  return (
    <Box sx={{ width: "100vw", height: "100vh", }}>
      <Box sx={{ width: '100vw', position: 'fixed', zIndex: 9 }}>
        <TopBar />
      </Box>
      <Box sx={{ display: "flex", flex: 1, height:"100vh",display: "flex",}}>
        <Box sx={{ width: isSidebarCollapsed ? 7 : 24, }}>
          <SideBar 
            setIsSidebarCollapsed={setIsSidebarCollapsed}
            setUser={setUser}
          />
        </Box>
        <Box
          sx={{
            marginLeft: isSidebarCollapsed ? 7 : 24, // Match the Sidebar width
            flex: 1,
            overflowY: "auto", // Ensure content scrolls
            scrollbarWidth: 'none',
            // height: "calc(100vh - 64px)", // Adjust height if needed to account for TopBar
            width: isSidebarCollapsed ? 91: 74,
            display: "flex",
            position: 'relative'
          }}
        >
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
