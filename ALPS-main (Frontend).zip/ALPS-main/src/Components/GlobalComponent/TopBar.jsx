import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Image from '../../assets/logo.png'; // Replace with your image path

const TopBar = () => {
  return (
    <AppBar position="static" style={{ backgroundColor: 'white', color: 'black' }}>
      <Toolbar>
        <img src={Image} alt="Logo" style={{ height: 30 }} />
        {/* Adjust height and styling as per your design */}
        <Typography variant="h6" sx={{ flexGrow: 1, marginLeft: '10px', fontWeight: 'bold' }}>
          Aaseya License & Permitting Solution (ALPS)
        </Typography>
      </Toolbar>
    </AppBar>
  );
};

export default TopBar;
