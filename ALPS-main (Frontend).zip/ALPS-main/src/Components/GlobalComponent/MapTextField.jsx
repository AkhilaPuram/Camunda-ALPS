import React, { useState } from 'react';
import { Box, TextField, InputAdornment, Dialog, DialogContent, DialogActions, Button } from '@mui/material';
import MapIcon from '@mui/icons-material/LocationOn';
import { MapContainer, TileLayer, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';


const MapTextField = () => {
  const [open, setOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('');

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSave = () => {
    // Implement save functionality here
    // alert("Map saved!");
    setOpen(false);
  };

  const handleSubmit = () => {
    // Implement submit functionality here
    // alert("Map submitted!");
    setOpen(false);
  };

  const LocationMarker = () => {
    useMapEvents({
      click(e) {
        const { lat, lng } = e.latlng;
        setSelectedLocation(`Lat: ${lat.toFixed(5)}, Lng: ${lng.toFixed(5)}`);
      }
    });
    return null;
  };

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
      <TextField
        variant="outlined"
        fullWidth
        value={selectedLocation}
        placeholder="Click to open map"
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <MapIcon onClick={handleClickOpen} style={{ cursor: 'pointer' }} />
            </InputAdornment>
          ),
        }}
        onClick={(e) => e.stopPropagation()}
      />
      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogContent>
          <MapContainer center={[17.44784, 78.37078]} zoom={13} style={{ height: '400px', width: '100%' }}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <LocationMarker />
          </MapContainer>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'space-between', padding: '16px' }}>
          <Box sx={{ display: 'flex', gap: '8px' }}>
            <Button 
              onClick={handleClose} 
              sx={{ 
                backgroundColor: '#795548', 
                color: 'white', 
                borderRadius: '16px', 
                textTransform: 'none', 
                fontSize: '14px',
                '&:hover': {
                  backgroundColor: '#795548',
                },
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSave} 
              sx={{ 
                backgroundColor: '#795548', 
                color: 'white', 
                borderRadius: '16px', 
                textTransform: 'none', 
                fontSize: '14px',
                '&:hover': {
                  backgroundColor: '#795548',
                },
              }}
            >
              Save
            </Button>
          </Box>
          <Button 
            onClick={handleSubmit} 
            sx={{ 
              backgroundColor: '#795548', 
              color: 'white', 
              borderRadius: '16px', 
              textTransform: 'none', 
              fontSize: '14px',
              '&:hover': {
                backgroundColor: '#795548',
              },
            }}
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default MapTextField;
