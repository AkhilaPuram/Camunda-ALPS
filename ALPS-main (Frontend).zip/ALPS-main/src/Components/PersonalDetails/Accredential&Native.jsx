import React, { useEffect, useState } from "react";
import {TextField,Button,Select,MenuItem,InputLabel,FormControl,FormHelperText,Container,Grid,Typography,Box,} from "@mui/material";
import HomeTwoToneIcon from "@mui/icons-material/HomeTwoTone";
import ApprovalIcon from '@mui/icons-material/Approval';
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import LocationIcon from "@mui/icons-material/Map";
import Maptextfield from "../GlobalComponent/MapTextField";

const CombinedForm = ({ setApplicationDetails, subcategory }) => {
  const [formValues, setFormValues] = useState({
    country: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    state: "",
    postal: "",
    firstName: "",
    middleName: "",
    lastName: "",
    dob: "",
    email: "",
    phone: "",
    licenseType: "", // Generalized field name for license
    referenceNumber: "", // Generalized field name for reference
    trainerNumber: "",
    waterfowlIdentificationTestNumber: "",
  });

  const [errors, setErrors] = useState({});
  const [age, setAge] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      });
    }

    if (name === "dob") {
      setAge(calculateAge(value));
    }
  };

  const calculateAge = (dob) => {
    if (!dob) return '';
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  useEffect(() => {
    setApplicationDetails(formValues);
  }, [formValues]);

  const validate = () => {
    const newErrors = {};
    if (!formValues.country) newErrors.country = "Country is required";
    if (!formValues.addressLine1) newErrors.addressLine1 = "Address Line 1 is required";
    if (!formValues.state) newErrors.state = "State is required";
    if (!formValues.postal) newErrors.postal = "Postal Code is required";
    if (!formValues.city) newErrors.city = "City is required";
    if (!formValues.firstName) newErrors.firstName = "First Name is required";
    if (!formValues.lastName) newErrors.lastName = "Last Name is required";
    if (!formValues.dob) newErrors.dob = "Date of Birth is required";
    if (!formValues.email) newErrors.email = "Email is required";
    if (!formValues.phone) newErrors.phone = "Phone is required";
    if (!formValues.licenseType) newErrors.licenseType = "License is required";
    if (!formValues.referenceNumber) newErrors.referenceNumber = "Reference Number is required";
    if (!formValues.trainerNumber) newErrors.trainerNumber = "Trainer Number is required";
    if (subcategory === 'Hunting' && !formValues.waterfowlIdentificationTestNumber) newErrors.waterfowlIdentificationTestNumber = "Waterfowl Identification Test Number is required";
    return newErrors;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formErrors = validate();
    if (Object.keys(formErrors).length === 0) {
      const requestData = {
        waterfowlIdentificationTestNumber: formValues.waterfowlIdentificationTestNumber,
        licenseType: formValues.licenseType,
        referenceNumber: formValues.referenceNumber,
        trainerNumber: formValues.trainerNumber,
        first_name: formValues.firstName,
        middle_name: formValues.middleName,
        last_name: formValues.lastName,
        date_of_birth: formValues.dob,
        email: formValues.email,
        phone: formValues.phone,
        country: formValues.country,
        city: formValues.city,
        address_line1: formValues.addressLine1,
        address_line2: formValues.addressLine2,
        state: formValues.state,
        postal_code: formValues.postal,
      };

      try {
        const response = await fetch(
          "http://localhost:8088/alps/addComposite",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(requestData),
          }
        );

        if (response.ok) {
          console.log("Form Submitted Successfully");
          console.log(requestData);
        } else {
          console.error("Form Submission Failed");
        }
      } catch (error) {
        console.error("Form Submission Error:", error);
      }
    } else {
      setErrors(formErrors);
    }
  };

  const countries = [
    { code: "US", name: "United States" },
    { code: "CA", name: "Canada" },
    // Add more countries as needed
  ];

  return (
    <Container>
      <Grid container spacing={2}></Grid>
      <form onSubmit={handleSubmit}>
        <Box sx={{ my: 4 }}>
          <Typography variant="h6" backgroundColor="F2EEED" gutterBottom>
            <PersonOutlineIcon sx={{ verticalAlign: "sub", backgroundColor: "#F2EEED", borderRadius: "50%", padding: "4px" }} /> Personal
            Information
          </Typography>
        </Box>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="First Name"
              name="firstName"
              value={formValues.firstName}
              onChange={handleChange}
              error={!!errors.firstName}
              helperText={errors.firstName}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Middle Name"
              name="middleName"
              value={formValues.middleName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Last Name"
              name="lastName"
              value={formValues.lastName}
              onChange={handleChange}
              error={!!errors.lastName}
              helperText={errors.lastName}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Date of Birth"
              name="dob"
              type="date"
              InputLabelProps={{ shrink: true }}
              value={formValues.dob}
              onChange={handleChange}
              error={!!errors.dob}
              helperText={errors.dob}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Age"
              value={age}
              InputProps={{ readOnly: true }}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Email"
              name="email"
              type="email"
              value={formValues.email}
              onChange={handleChange}
              error={!!errors.email}
              helperText={errors.email}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Phone"
              name="phone"
              value={formValues.phone}
              onChange={handleChange}
              error={!!errors.phone}
              helperText={errors.phone}
            />
          </Grid>
        </Grid>
        <Box sx={{ my: 4 }}>
          <Typography variant="h6" gutterBottom>
            <HomeTwoToneIcon sx={{ verticalAlign: "sub", backgroundColor: "#F2EEED", borderRadius: "50%", padding: "4px"}} /> Address
          </Typography>
        </Box>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.country}>
              <InputLabel
                id="country-label"
                sx={{
                  paddingRight: "10px",
                  "&.Mui-focused": {
                    transform: "translate(13px, -8px) scale(0.65)",
                  },
                }}
              >
                Country
              </InputLabel>
              <Select
                labelId="country-label"
                id="country"
                name="country"
                value={formValues.country}
                onChange={handleChange}
                label="Country"
                sx={{
                  "& .MuiSelect-select:focus": {
                    backgroundColor: "inherit",
                  },
                }}
              >
                {countries.map((country) => (
                  <MenuItem key={country.code} value={country.code}>
                    {country.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.country && (
                <FormHelperText>{errors.country}</FormHelperText>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Address Line 1"
              name="addressLine1"
              value={formValues.addressLine1}
              onChange={handleChange}
              error={!!errors.addressLine1}
              helperText={errors.addressLine1}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Address Line 2"
              name="addressLine2"
              value={formValues.addressLine2}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="City"
              name="city"
              value={formValues.city}
              onChange={handleChange}
              error={!!errors.city}
              helperText={errors.city}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="State"
              name="state"
              value={formValues.state}
              onChange={handleChange}
              error={!!errors.state}
              helperText={errors.state}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <TextField
              fullWidth
              label="Postal Code"
              name="postal"
              value={formValues.postal}
              onChange={handleChange}
              error={!!errors.postal}
              helperText={errors.postal}
            />
          </Grid>
        </Grid>
        <Box sx={{ my: 4 }}>
          <Typography variant="h6" gutterBottom>
            <ApprovalIcon sx={{ verticalAlign: "sub", backgroundColor: "#F2EEED", borderRadius: "50%", padding: "4px"}} /> License Information
          </Typography>
        </Box>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label={subcategory === 'Hunting' ? "License Number" : "Type of ShotGun License"}
              name="licenseType"
              value={formValues.licenseType}
              onChange={handleChange}
              error={!!errors.licenseType}
              helperText={errors.licenseType}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label={subcategory === 'Hunting' ? "Reference Accreditation Number" : "Reference Number"}
              name="referenceNumber"
              value={formValues.referenceNumber}
              onChange={handleChange}
              error={!!errors.referenceNumber}
              helperText={errors.referenceNumber}
            />
          </Grid>
          {subcategory === 'Hunting' && (
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Waterfowl Identification Test Number"
                name="waterfowlIdentificationTestNumber"
                value={formValues.waterfowlIdentificationTestNumber}
                onChange={handleChange}
                error={!!errors.waterfowlIdentificationTestNumber}
                helperText={errors.waterfowlIdentificationTestNumber}
              />
            </Grid>
          )}
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Trainer Number"
              name="trainerNumber"
              value={formValues.trainerNumber}
              onChange={handleChange}
              error={!!errors.trainerNumber}
              helperText={errors.trainerNumber}
            />
          </Grid>
        </Grid>
        <Box sx={{ my: 4 }}>
           <Typography variant="h6" gutterBottom>
             <LocationIcon sx={{ verticalAlign: "sub", backgroundColor: "#F2EEED", borderRadius: "50%", padding: "4px" }} /> MAP
           </Typography>
         </Box>
         <Grid container spacing={2}>
           <Grid item xs={12} sm={6}>
           <Maptextfield
              fullWidth
              label="Latitude & Longitude"
              name="latitude & longitude"
              value={formValues.approvedHuntingLicense}
              onChange={handleChange}
              error={!!errors.approvedHuntingLicense}
              helperText={errors.approvedHuntingLicense}
            />
          </Grid>
         </Grid>
      </form>
    </Container>
  );
};

export default CombinedForm;
