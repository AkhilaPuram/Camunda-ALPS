import React, { useState } from "react";
import { Paper, Typography, Collapse, Dialog, DialogTitle, DialogContent, DialogActions, Grid, TextField } from "@mui/material";
import { AttachFile, ExpandMore, ExpandLess } from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";

const DocumentSection = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  marginBottom: theme.spacing(2),
}));

const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#c55a3321",
  ...theme.typography.body2,
  padding: "12px",
  textAlign: "center",
  color: "#795548",
  fontWeight: 600,
  borderRadius: "2em",
  border: "1px solid #795548",
  "&:hover": {
    backgroundColor: "#795548",
    color: "White",
  },
}));

const DocumentItem = ({ title, mandatory, setDocumentDetails }) => {
  const [expanded, setExpanded] = useState(false);
  const [fileName, setFileName] = useState("");
  const [openAttachmentDialog, setOpenAttachmentDialog] = useState(false);
  const [documentName, setDocumentName] = useState('');
  const [documentContent, setDocumentContent] = useState('');
  const [document_type, setdocument_type] = useState('');

  const handleFileChange = (event) => {
    if (event.target.files?.length > 0) {
      const file = event.target.files[0];
      setFileName(file.name);
    } else {
      setFileName("");
    }
  };

  const updateFiles = () => {
    setDocumentDetails(prev => [
      ...prev,
      {
        document_type: title, // Use the title for document_type
        name: documentName,
        content: documentContent
      }
    ]);
  }

  return (
    <>
      <DocumentSection elevation={3}>
        <div
          onClick={() => setExpanded(!expanded)}
          style={{ cursor: "pointer", display: "flex", alignItems: "center" }}
        >
          {expanded ? <ExpandLess /> : <ExpandMore />}
          <Typography
            variant="h6"
            component="h3"
            style={{ flexGrow: 1, marginLeft: 8 }}
          >
            {title}
          </Typography>
          {mandatory ? (
            <Typography color="error">Mandatory</Typography>
          ) : (
            <Typography color="textSecondary">Optional</Typography>
          )}
        </div>
        <Collapse in={expanded}>
          <div style={{ display: "flex", alignItems: "center", marginTop: 16 }}>
            <Typography variant="body1" style={{ marginRight: 16 }}>
              {title.split("-")[1].trim()}
            </Typography>
            <StyledButton onClick={() => setOpenAttachmentDialog(true)}>Attach</StyledButton>
            {fileName && (
              <>
                <Typography variant="body1" style={{ marginLeft: 16 }}>
                  {documentName}
                </Typography>
                <Typography variant="body1" style={{ marginLeft: 16 }}>
                  {fileName}
                </Typography>
              </>
            )}
          </div>
        </Collapse>
      </DocumentSection>
      <Dialog open={openAttachmentDialog} onClose={() => setOpenAttachmentDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>Add attachment</DialogTitle>
        <DialogContent>
          <Grid container direction={'column'} rowGap={3}>
            <Grid item>
              <Typography>Name</Typography>
              <TextField
                fullWidth
                value={documentName}
                onChange={(e) => setDocumentName(e.target.value)}
              />
            </Grid>
            <Grid item>
              <Typography>Content</Typography>
              <TextField
                fullWidth
                multiline
                rows={3}
                value={documentContent}
                onChange={(e) => setDocumentContent(e.target.value)}
              />
            </Grid>
            <Grid item>
              <StyledButton
                variant="contained"
                component="label"
                startIcon={<AttachFile />}
              >
                Attach
                <input type="file" hidden onChange={handleFileChange} />
              </StyledButton>
              <Typography>
                {fileName}
              </Typography>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <StyledButton onClick={() => setOpenAttachmentDialog(false)}>Cancel</StyledButton>
          <StyledButton onClick={() => {
            setOpenAttachmentDialog(false)
            updateFiles()
          }}>Submit</StyledButton>
        </DialogActions>
      </Dialog>
    </>
  );
};

const DocumentIntake = ({ setDocumentDetails }) => {
  return (
    <div style={{ paddingLeft: 16 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Document intake
      </Typography>
      <Typography variant="body1" paragraph>
        Please review the requirements listed below that have been set for this
        funding program. If the requirement specifies a document type you will
        need to use the upload feature below to add it to the application. Other
        document types can also be uploaded. If your application and
        documentation is missing any of the requirements your application may be
        rejected or may be reduced in its overall score.
      </Typography>
      <DocumentItem title="Document - NIN Number" mandatory setDocumentDetails={setDocumentDetails} />
      <DocumentItem title="Document - R License Number" mandatory setDocumentDetails={setDocumentDetails} />
      <DocumentItem title="Document - Trainer Number" setDocumentDetails={setDocumentDetails} />
    </div>
  );
};

export default DocumentIntake;
