import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, Grid, Typography } from "@mui/material";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Details from "../ApplicationRequest/details";
import Accredential from "./Accredential&Native";
import DocumentIntake from "./Intake";
import Questionnaire from "./Questionnaire";
import Consent from "./Consent";
import Payment from "./Payment";
import axios from "axios";
import { SnackContext } from "../GlobalComponent/SnackProvider"; // Import SnackContext

const steps = ["Accredential", "Document Intake", "Questionnaire", "Consent Form", "Payment"];

const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#c55a3321",
  ...theme.typography.body2,
  padding: "8px 30px",
  textAlign: "center",
  color: "#795548",
  fontWeight: 600,
  fontSize: "0.8rem",
  borderRadius: "2em",
  border: "1px solid #795548",
  "&:hover": {
    backgroundColor: "#795548",
    color: "White",
  },
}));

const SaveButton = styled(StyledButton)(({ theme }) => ({
  backgroundColor: "#d3d3d3",
  color: "#000",
  border: "1px solid #ccc",
  "&:hover": {
    backgroundColor: "#bbb",
    color: "#000",
  },
}));

const CustomStep = styled(Step)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
}));

const CustomStepLabel = styled(StepLabel)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  color: "#795548",
  alignItems: "center",
  marginTop: theme.spacing(2),
  "& .MuiStepIcon-root": {
    marginBottom: theme.spacing(1),
  },
}));

export default function HorizontalLinearStepper() {
  const [activeStep, setActiveStep] = useState(0);
  const [skipped, setSkipped] = useState(new Set());
  const [applicationDetails, setApplicationDetails] = useState({});
  const [documentDetails, setDocumentDetails] = useState([]);
  const [questionnaireAnswers, setQuestionnaireAnswers] = useState({});
  const navigate = useNavigate();
  const location = useLocation();
  const programDetails = location.state?.programDetails;
  const licenseInfo = location.state?.licenseInfo;
  const { setSnack } = React.useContext(SnackContext); // Use SnackContext

  const isStepOptional = (step) => step === 1;
  const isStepSkipped = (step) => skipped.has(step);

  const handleNext = async () => {
    let newSkipped = skipped;
    if (isStepSkipped(activeStep)) {
      newSkipped = new Set(newSkipped.values());
      newSkipped.delete(activeStep);
    }

    if (activeStep === steps.length - 1) {
      const hasYesAnswer = Object.values(questionnaireAnswers).includes("yes");

      if (hasYesAnswer) {
        setSnack({
          open: true,
          message: "The case is Rejected due to Offence",
          severity: "error",
        });
        navigate("/dashboard");
        return;
      } else {
        documentDetails.map((document) => {
          document.license_id = licenseInfo?.businessKey;
        });

        const year = new Date(applicationDetails?.dob).getFullYear();
        const month = String(new Date(applicationDetails?.dob).getMonth() + 1).padStart(2, '0');
        const day = String(new Date(applicationDetails?.dob).getDate()).padStart(2, '0');
        const formattedDate = `${day}/${month}/${year}`;

        try {
          await axios.post(`${import.meta.env.VITE_BASE_URL}/alps/addPersonBasicDetails`, {
            first_name: applicationDetails?.firstName,
            middle_name: applicationDetails?.middleName,
            last_name: applicationDetails?.lastName,
            email_id: applicationDetails?.email,
            phone_number: applicationDetails?.phone,
            date_of_birth: formattedDate,
            country: applicationDetails?.country,
            address_line1: applicationDetails?.addressLine1,
            address_line2: applicationDetails?.addressLine2,
            city: applicationDetails?.city,
            state: applicationDetails?.state,
            postal_code: applicationDetails?.postal,
            approved_hunting_organization: applicationDetails?.approvedHuntingLicense,
            rlicense_accreditation_number: applicationDetails?.rLicenseAccreditationNumber,
            trainer_number: applicationDetails?.trainerNumber,
            waterfowl_identification_test_number: applicationDetails?.waterfowlIdentificationTestNumber,
            license_id: licenseInfo?.businessKey,
            action: "submit",
          });
          await axios.post(`${import.meta.env.VITE_BASE_URL}/alps/addDocumentIntakeData`, documentDetails);
          setSnack({
            open: true,
            message: `The case with ${licenseInfo?.businessKey} moved to the Reviewer`,
            severity: "success",
          });
          navigate(`/dashboard`);
        } catch (error) {
          console.log(error);
        }
      }
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
      setSkipped(newSkipped);
    }
  };

  const handleBack = () => {
    if (activeStep === 0) {
      navigate(-1);
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  const handleSave = async () => {
    documentDetails.map((document) => {
      document.license_id = licenseInfo?.businessKey;
    });

    const year = new Date(applicationDetails?.dob).getFullYear();
    const month = String(new Date(applicationDetails?.dob).getMonth() + 1).padStart(2, '0');
    const day = String(new Date(applicationDetails?.dob).getDate()).padStart(2, '0');
    const formattedDate = `${day}/${month}/${year}`;

    try {
      await axios.post(`${import.meta.env.VITE_BASE_URL}/alps/addPersonBasicDetails`, {
        first_name: applicationDetails?.firstName,
        middle_name: applicationDetails?.middleName,
        last_name: applicationDetails?.lastName,
        email_id: applicationDetails?.email,
        phone_number: applicationDetails?.phone,
        date_of_birth: formattedDate,
        country: applicationDetails?.country,
        address_line1: applicationDetails?.addressLine1,
        address_line2: applicationDetails?.addressLine2,
        city: applicationDetails?.city,
        state: applicationDetails?.state,
        postal_code: applicationDetails?.postal,
        approved_hunting_organization: applicationDetails?.approvedHuntingLicense,
        rlicense_accreditation_number: applicationDetails?.rLicenseAccreditationNumber,
        trainer_number: applicationDetails?.trainerNumber,
        waterfowl_identification_test_number: applicationDetails?.waterfowlIdentificationTestNumber,
        license_id: licenseInfo?.businessKey,
        action: "save",
      });
      await axios.post(`${import.meta.env.VITE_BASE_URL}/alps/addDocumentIntakeData`, documentDetails);
      setSnack({
        open: true,
        message: "The data has been saved Successfully",
        severity: "success",
      });
    } catch (error) {
      console.log(error);
    }
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  return (
    <Box sx={{ width: "100%", m: 2, mt: 10, px: 10 }}>
      <Stepper activeStep={activeStep} sx={{ px: 20 }}>
        {steps.map((label, index) => {
          const stepProps = {};
          const labelProps = {};
          if (isStepOptional(index)) {
            labelProps.optional = <Typography variant="caption"></Typography>;
          }
          if (isStepSkipped(index)) {
            stepProps.completed = false;
          }
          return (
            <CustomStep key={label} {...stepProps}>
              <CustomStepLabel {...labelProps}>{label}</CustomStepLabel>
            </CustomStep>
          );
        })}
      </Stepper>
      <React.Fragment>
        <Box sx={{ pt: 5, px: 2 }}>
          {activeStep === 0 && <Accredential setApplicationDetails={setApplicationDetails} subcategory={programDetails?.subcategory} />}
          {activeStep === 1 && <DocumentIntake setDocumentDetails={setDocumentDetails} />}
          {activeStep === 2 && <Questionnaire setQuestionnaireAnswers={setQuestionnaireAnswers} subcategory={programDetails?.subcategory} />}
          {activeStep === 3 && <Consent subcategory={programDetails?.subcategory}/>}
          {activeStep === 4 && <Payment />}
        </Box>
        <Grid container justifyContent='space-between' sx={{ pt: 4, px: 5 }}>
          <Grid item xs={6}>
            <StyledButton color="inherit" onClick={handleBack}>
              Back
            </StyledButton>
          </Grid>
          <Grid item xs={6} container columnGap={2} justifyContent='flex-end'>
            <StyledButton onClick={handleSave}>
              Save
            </StyledButton>
            <StyledButton onClick={handleNext}>
              {activeStep === steps.length - 1 ? "Submit" : "Next"}
            </StyledButton>
          </Grid>
        </Grid>
      </React.Fragment>
      <Grid container px={5}>
        <Details programDetails={programDetails} />
      </Grid>
    </Box>
  );
}
