import React, { useState } from "react";
import {Button,Dialog,DialogActions,DialogContent,DialogTitle,TextField,Typography,Grid,Paper,Link,} from "@mui/material";

const Payment = () => {
  const [open, setOpen] = useState(false);
  const [paymentType, setPaymentType] = useState("");
  const [otpOpen, setOtpOpen] = useState(false);
  const [cardDetails, setCardDetails] = useState({
    number: "",
    cvv: "",
    expiry: "",
  });
  const [upiId, setUpiId] = useState("");
  const [otp, setOtp] = useState("");

  const handleOpen = (type) => {
    setPaymentType(type);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setOtpOpen(false);
    setPaymentType("");
    setCardDetails({
      number: "",
      cvv: "",
      expiry: "",
    });
    setUpiId("");
    setOtp("");
  };

  const handleCardDetailChange = (e) => {
    setCardDetails({
      ...cardDetails,
      [e.target.name]: e.target.value,
    });
  };

  const handleOtpSubmit = () => {
    // Handle OTP submission logic here
    console.log("OTP submitted:", otp);
    handleClose();
  };

  const handleSubmit = () => {
    if (paymentType === "UPI") {
      // Handle UPI submission logic here
      console.log("UPI ID submitted:", upiId);
      handleClose();
    } else {
      setOtpOpen(true);
    }
  };

  return (
    <Paper sx={{ p: 4, backgroundColor: "#fff",  }}>
      <Typography variant="h4" gutterBottom style={{ fontWeight: "bold", paddingBottom: "20px" }}>
        Payment
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6" gutterBottom style={{ fontWeight: "bold", paddingBottom: "10px" }}>
            <span role="img" aria-label="summary">
              📝
            </span>{" "}
            Account Summary
          </Typography>
          <Typography variant="body1" gutterBottom style={{ fontWeight: "bold", paddingLeft: "30px" }}>
            Licence Fee:
          </Typography>
          <Typography gutterBottom style={{ paddingLeft: "30px" }}>250</Typography>
          <Typography variant="body1" gutterBottom style={{ fontWeight: "bold", paddingLeft: "30px" }}>
            Duration Units:
          </Typography>
          <Typography gutterBottom style={{ paddingLeft: "30px" }}>499</Typography>
          <Typography variant="body1" gutterBottom style={{ fontWeight: "bold", paddingLeft: "30px" }}>
            Total Cost:
          </Typography>
          <Typography gutterBottom style={{ paddingLeft: "30px" }}>250</Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6" gutterBottom style={{ fontWeight: "bold", paddingBottom: "10px" }}>
            <span role="img" aria-label="payment">
              💵
            </span>{" "}
            Select Payment Mode
          </Typography>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <Link
              href="#"
              onClick={() => handleOpen("Credit Card")}
              style={{
                margin: "5px 0",
                color: "black",
                textDecoration: "none",
                paddingBottom: "10px"
                
              }}
              onMouseOver={(e) => (e.target.style.textDecoration = "underline")}
              onMouseOut={(e) => (e.target.style.textDecoration = "none")}
            >
              <span role="img" aria-label="credit-card">
                💳
              </span>{" "}
              Credit Card
            </Link>
            <Link
              href="#"
              onClick={() => handleOpen("Debit Card")}
              style={{
                margin: "5px 0",
                color: "black",
                textDecoration: "none",
                paddingBottom: "10px"
              }}
              onMouseOver={(e) => (e.target.style.textDecoration = "underline")}
              onMouseOut={(e) => (e.target.style.textDecoration = "none")}
            >
              <span role="img" aria-label="debit-card">
                💳
              </span>{" "}
              Debit Card
            </Link>
            <Link
              href="#"
              onClick={() => handleOpen("UPI")}
              style={{
                margin: "5px 0",
                color: "black",
                textDecoration: "none",
                paddingBottom: "10px"
              }}
              onMouseOver={(e) => (e.target.style.textDecoration = "underline")}
              onMouseOut={(e) => (e.target.style.textDecoration = "none")}
            >
              <span role="img" aria-label="upi">
                📲
              </span>{" "}
              UPI
            </Link>
          </div>
        </Grid>
      </Grid>

      {/* Card Details Dialog */}
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>
          {paymentType === "Credit Card"
            ? "Credit Card Details"
            : paymentType === "Debit Card"
            ? "Debit Card Details"
            : "UPI Details"}
        </DialogTitle>
        <DialogContent>
          {paymentType === "UPI" ? (
            <TextField
              autoFocus
              margin="dense"
              label="UPI ID"
              type="text"
              fullWidth
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
            />
          ) : (
            <>
              <TextField
                autoFocus
                margin="dense"
                label="Card Number"
                type="text"
                fullWidth
                name="number"
                value={cardDetails.number}
                onChange={handleCardDetailChange}
              />
              <TextField
                margin="dense"
                label="CVV"
                type="text"
                fullWidth
                name="cvv"
                value={cardDetails.cvv}
                onChange={handleCardDetailChange}
              />
              <TextField
                margin="dense"
                label="Expiry Date"
                type="text"
                fullWidth
                name="expiry"
                value={cardDetails.expiry}
                onChange={handleCardDetailChange}
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      {/* OTP Dialog */}
      <Dialog open={otpOpen} onClose={handleClose}>
        <DialogTitle>Enter OTP</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="OTP"
            type="text"
            fullWidth
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleOtpSubmit} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    </Paper>
  );
};

export default Payment;
