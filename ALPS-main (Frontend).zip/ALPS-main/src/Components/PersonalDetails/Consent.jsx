import React, { useRef, useState } from 'react';
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Typography,
  Paper,
} from '@mui/material';
import SignatureCanvas from 'react-signature-canvas';

const ConsentForm = ({ onClose, subcategory }) => {
  const [checked, setChecked] = useState(false);
  const [signed, setSigned] = useState(false);
  const sigCanvas = useRef({});

  const handleCheck = (event) => {
    setChecked(event.target.checked);
  };

  const handleClear = () => {
    sigCanvas.current.clear();
    setSigned(false);
  };

  const handleAccept = () => {
    if (!sigCanvas.current.isEmpty()) {
      setSigned(true);
    }
  };

  const handleSubmit = () => {
    if (checked && signed) {
      const signature = sigCanvas.current.toDataURL();
      // Handle the submit action, send the signature and other form data to the server
    } else {
      alert('Please agree to the terms and sign the form.');
    }
  };

  const huntingText = `
    State law requires this consent form to be signed and agreed by you.
    The Parties to this Consent Agreement are the Department and the Respondent, including Respondent’s operating divisions and subsidiaries.
    The Respondent agrees that no confidential information be used for personal use and benefits.
    The Respondent certifies that as an individual, or any member of an entity, has not been convicted under Federal or State Law.
    This Consent Agreement shall become binding on the Department only when the Assistant Secretary-State Law approves it by entering the Order, which will have the same force and effect as a decision.
  `;

  const firearmsText = `
    State law requires this consent form to be signed and agreed by you. The form outlines the borrower’s responsibilities, including adhering
    to all relevant UK laws, safety protocols, and proper storage 
    requirements. Both parties must acknowledge and agree to the 
    terms of the consent by signing the document, digitally. The form also allows for the owner to revoke the consent 
    at any time, requiring the immediate return of the shotgun. By 
    completing this form, the owner ensures that the lending of their 
    shotgun is legally documented and compliant with UK firearms 
    regulations, safeguarding both parties involved.
  `;

  const displayText = subcategory === "Hunting" ? huntingText : firearmsText;

  return (
    <Paper sx={{ p: 4 }}>
      <Typography variant="h6" component="h2" gutterBottom>
        <Box component="span" sx={{ display: 'flex', marginRight: 1, fontWeight:"bold" }}>
          Consent Form
        </Box>
      </Typography>
      <Typography variant="body1" paragraph>
        {displayText}
      </Typography>
      <FormControlLabel
        control={<Checkbox checked={checked} onChange={handleCheck} />}
        label="I Agree"
      />
      <Box
        sx={{
          border: '1px solid #ccc',
          padding: 2,
          marginTop: 2,
          minHeight: 100,
          width: "50%",
          paddingRight: "50px",
          marginLeft: 60,
          position: 'relative'
        }}
      >
        <SignatureCanvas
          ref={sigCanvas}
          penColor="black"
          onEnd={() => setSigned(true)}
          canvasProps={{ width: 500, height: 100, className: 'sigCanvas' }}
        />
        {signed && (
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
            <Button onClick={handleAccept} sx={{ backgroundColor: '#795548', color: '#fff' }} variant="contained">
              Accept
            </Button>
            <Button onClick={handleClear} sx={{ color: '#795548', borderColor: '#795548' }} variant="outlined">
              Clear
            </Button>
          </Box>
        )}
      </Box>
    </Paper>
  );
};

export default ConsentForm;
