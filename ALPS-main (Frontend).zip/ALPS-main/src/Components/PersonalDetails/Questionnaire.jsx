
import React, { useState, useEffect } from 'react';
import { Paper, Typography, RadioGroup, FormControlLabel, Radio } from '@mui/material';
import { styled } from '@mui/material/styles';

const QuestionnaireSection = styled(Paper)(({ theme }) => ({
    padding: theme.spacing(3),
    marginBottom: theme.spacing(3),
}));

const Question = styled(Typography)(({ theme }) => ({
    marginTop: theme.spacing(2),
}));

const StyledRadio = styled(Radio)(({ theme }) => ({
    '&.Mui-checked': {
        color: '#795548 !important',
    },
}));

const Questionnaire = ({ setQuestionnaireAnswers, subcategory }) => {
    // Log the subcategory to see what is being passed
    console.log('Subcategory:', subcategory);

    const huntingQuestions = [
        "In the last 10 years have you ever been found guilty of any offence under clauses 30(4), 32(2) or (3) of the Firearms regulation 2018?",
        "In the last 10 years have you been found guilty of offence under sections 45, 56, 58Q or 70 of the national parks and wildlife Act 1974?",
        "In the last 10 years, have you been found guilty of any offence in NSW or elsewhere involving cruelty or harm to animals, personal violence, damage to property or unlawful entry onto land?"
    ];

    const firearmsQuestions = [
        "Do you currently hold a valid UK shotgun license?", 
        "Have you lived at your current address for more than 2 years?",
        "Have you ever been convicted of a criminal offense?", 
        "Have you ever been diagnosed with any mental health conditions, including depression, anxiety, or substance abuse?",
        "Have you completed any fireman or shotgun safety training courses?"
    ];

    const questions = subcategory === "Hunting" ? huntingQuestions : firearmsQuestions;

    const [answers, setAnswers] = useState(
        questions.reduce((acc, _, index) => {
            acc[`question${index}`] = null;
            return acc;
        }, {})
    );

    const handleRadioChange = (event, index) => {
        const newAnswers = {
            ...answers,
            [`question${index}`]: event.target.value,
        };
        setAnswers(newAnswers);
        setQuestionnaireAnswers(newAnswers);  // Pass answers to the parent component
    };

    return (
        <div style={{ paddingLeft: 16 }}>
            <Typography variant="h4" component="h1" fontWeight="bold" gutterBottom>
                Answer the questions below
            </Typography>
            <Typography variant="h5" component="h2" gutterBottom>
                {subcategory} Questionnaire
            </Typography>
            <Typography variant="body1" paragraph>
                All questions are mandatory*
            </Typography>
            {questions.map((question, index) => (
                <QuestionnaireSection elevation={3} key={index}>
                    <Question variant="body1">{question}</Question>
                    <RadioGroup
                        row
                        aria-label={`question-${index}`}
                        name={`question-${index}`}
                        value={answers[`question${index}`] || ''}
                        onChange={(event) => handleRadioChange(event, index)}
                    >
                        <FormControlLabel
                            value="yes"
                            control={<StyledRadio />}
                            label="Yes"
                        />
                        <FormControlLabel
                            value="no"
                            control={<StyledRadio />}
                            label="No"
                        />
                        <FormControlLabel
                            value="not-applicable"
                            control={<StyledRadio />}
                            label="Not applicable"
                        />
                    </RadioGroup>
                </QuestionnaireSection>
            ))}
        </div>
    );
};

export default Questionnaire;
