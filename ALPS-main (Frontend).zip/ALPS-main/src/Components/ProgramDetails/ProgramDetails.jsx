import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import Grid from "@mui/material/Grid";
import Stack from "@mui/material/Stack";
import { styled } from "@mui/material/styles";
import { Box, Button, Paper, alpha } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import axios from "axios";

const Item = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(0.8),
  textAlign: "start",
  color: theme.palette.text.primary,
}));

const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#c55a3321",
  ...theme.typography.body2,
  padding: "12px",
  textAlign: "center",
  color: "#795548",
  fontWeight: 600,
  width: "8vw",
  borderRadius: "2em",
  border: "1px solid #795548",
  '&:hover': {
        backgroundColor: "#795548",
        color: "White",
    },
}));

const ProgramDetails = () => {
  const navigate = useNavigate();
  const [HuntingData, setHuntingData] = useState([]);
  const [ programDetails, setProgramDetails ] = useState({})
  const location = useLocation()
  const subCategoryOption = location.state?.subCategoryOption
  console.log(subCategoryOption)
  
  useEffect(() => {
    const fetchProgramDetails = async () => {
      try {
        const programDetails = await axios({
          method: 'get',
          url: `${import.meta.env.VITE_BASE_URL}/alps/getProgramDetails?sub_sub_category=${subCategoryOption}`
        })
        console.log(programDetails?.data[0])
        setProgramDetails(programDetails?.data[0])
      } catch(error) {
        console.log(error)
      }
    }
    fetchProgramDetails()
  }, [subCategoryOption]);

  const startApplication = async () => {
    const applicationResponse = await axios({
      method: 'post',
      url: `${import.meta.env.VITE_BASE_URL}/alps/startALPSProcess`,
      data: {
        category: programDetails?.category,
        subcategory: programDetails?.subcategory,
        subsubcategory: programDetails?.program_id,
        createdBy: localStorage.getItem('userEmail'),
        applicantId: programDetails?.application_for
      }
    })
    console.log(applicationResponse?.data)
    navigate(`/apply`, {state: {programDetails:programDetails, licenseInfo: applicationResponse?.data}})
  }

  const rows = [
    { doctype: "NIN", Mandatory: "Mandatory", Description: "NIN" },
    { doctype: "R-License Accredition Number", Mandatory: "Mandatory", Description: "1234567" },
    { doctype: "Trainer Number", Mandatory: "Mandatory", Description: "23657895" },
  ];

  return (
    <Grid container spacing={2} direction="column" m={1} mt={10}>
      <Grid item xs={12}>
        <Paper sx={{ padding: "2em", overflowY: "auto" }}>
          <Grid container spacing={2}>
            <Grid item xs={12} mb={2}>
              <Stack direction="row" justifyContent="space-between">
                <Item sx={{ fontWeight: 600, fontSize: "2em" }}>Program Details</Item>
              </Stack>
            </Grid>
            <Paper sx={{ p: 3, width: "80%" }}>
              <Grid item xs={12}>
                <Stack spacing={1}>
                  <Item sx={{ fontWeight: "600", fontSize: "1.2em" }}>Description</Item>
                  <Item>{programDetails?.description}</Item>
                </Stack>
              </Grid>
              <Grid item container spacing={2}>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Application Fee</Item>
                  <Item>{programDetails?.application_fee}</Item>
                </Grid>
                {/* <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Application for</Item>
                  <Item>{programDetails?.application_for}</Item>
                </Grid> */}
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Category</Item>
                  <Item>{programDetails?.subcategory}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>SubCategory</Item>
                  <Item>{programDetails?.program_name}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Application start Date</Item>
                  <Item>{programDetails?.application_startdate}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Application end Date</Item>
                  <Item>{programDetails?.application_enddate}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Duration</Item>
                  <Item>{programDetails?.duration}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Inspection</Item>
                  <Item>{programDetails?.inspection}</Item>
                </Grid>
                <Grid item xs={12} md={6} lg={4}>
                  <Item sx={{ fontWeight: "600" }}>Compliance</Item>
                  <Item>{programDetails?.compliance}</Item>
                </Grid>
              </Grid>
            </Paper>
            <Paper sx={{ paddingRight: "0em", overflowY: "auto", width: "79%", marginTop: "20px" }}>
              <Item sx={{ fontWeight: 600, fontSize: "1.5em" }}>Documents</Item>
              <TableContainer component={Paper} sx={{ marginTop: "1em" }}>
                <Table aria-label="simple table">
                  <TableHead sx={{ backgroundColor: "#c55a3321" }}>
                    <TableRow>
                      <TableCell sx={{ fontWeight: "600" }} align="left">Document Type</TableCell>
                      <TableCell sx={{ fontWeight: "600" }} align="left">Is Mandatory</TableCell>
                      <TableCell sx={{ fontWeight: "600" }} align="left">Description shown to Applicant</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.doctype}>
                        <TableCell align="left">{row.doctype}</TableCell>
                        <TableCell align="left">{row.Mandatory}</TableCell>
                        <TableCell align="left">{row.Description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Grid>
          <Grid item xs={12} mt={2}>
            <Stack spacing={2} direction="row" justifyContent="space-between">
              <StyledButton onClick={() => navigate('/create')}>Back</StyledButton>
              <StyledButton onClick={() => {startApplication()}}>Create</StyledButton>
            </Stack>
          </Grid>
        </Paper>
      </Grid>
    </Grid>
  );
};

export default ProgramDetails;
