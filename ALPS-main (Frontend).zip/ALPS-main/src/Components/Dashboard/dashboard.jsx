import React from "react";
import { Paper, Grid, Avatar, Typography, Box } from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import BusinessIcon from "@mui/icons-material/Business";
import HomeWorkIcon from "@mui/icons-material/HomeWork";
import DirectionsCarIcon from "@mui/icons-material/DirectionsCar";
import AssignmentIndIcon from "@mui/icons-material/AssignmentInd";
import LicensePermitImage from "../../assets/PermitLicense.png"; // Update the path accordingly
import Details from "../ApplicationRequest/details";
import Map from "../GlobalComponent/MapTextField";
import ProgramDetails from "../ProgramDetails/ProgramDetails";
import Program from "../Program/Program";
import DocumentsIntake from "../PersonalDetails/Intake";
import Consent from "../PersonalDetails/Consent";
import DashboardTable from "./dashboardTable";

const avatars = [
  { label: "Add Person", icon: <AddIcon sx={{ color: "#B29B93" }} /> },
  { label: "Add Business", icon: <BusinessIcon sx={{ color: "#B29B93" }} /> },
  { label: "Add Facility", icon: <HomeWorkIcon sx={{ color: "#B29B93" }} /> },
  {
    label: "Add Vehicle",
    icon: <DirectionsCarIcon sx={{ color: "#B29B93" }} />,
  },
  {
    label: "Add Applicant Request",
    icon: <AssignmentIndIcon sx={{ color: "#B29B93" }} />,
  },
];

const Home = () => {
  return (
    <Paper sx={{ width: "100%", height:'88%', m: 2, mt: 10, p:2.5 }}>
            <Grid container spacing={3} >
        {avatars.map((item, index) => (
          <Grid item key={index}>
            <Paper
              sx={{
                // marginBottom:'80px', //This is to have gap between table and avatars 
                padding: "8px",
                textAlign: "center",
                borderRadius: "12px",
                boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)",
                width: "100%",
                height: 70,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                   marginRight: "30px",
                }}
              >
                <Avatar sx={{ bgcolor: "#F2EEED", width: 48, height: 48 }}>
                  {item.icon}
                </Avatar>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "bold",
                    marginLeft: "10px",
                  }}
                >
                  {item.label}
                </Typography>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
      <DashboardTable/>
    </Paper>
  );
};

export default Home;
