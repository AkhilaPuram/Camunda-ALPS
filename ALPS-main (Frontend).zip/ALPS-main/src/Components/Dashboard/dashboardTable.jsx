import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Typography, Box } from "@mui/material";
import axios from "axios";
import { Link } from "react-router-dom";

const columns = [
 
  {
    field: "applicantId",
    headerName: "Applicant",
    flex: 1,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "category",
    headerName: "Category",
    flex: 0.6,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "subcategory",
    headerName: "Subcategory",
    flex: 0.6,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "status",
    headerName: "Status",
    flex: 1,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "createdBy",
    headerName: "Created By",
    flex: 1,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "license_Id",
    headerName: "License ID",
    flex: 1,
    headerClassName: "table-header",
    cellClassName: "table-cell",
  },
  {
    field: "action",
    headerName: "Action",
    hide: localStorage.getItem('userRole') === 'APPLICANT',
    flex: 0.5,
    headerClassName: "table-header",
    cellClassName: "table-cell",
    renderCell: (params) => {
      return (localStorage.getItem('userRole') === 'REVIEWER' ? <Link to={`/review`} state={{ license_Id: params.row.license_Id }}>Review</Link> : <Link to={`/approve`} state={{ license_Id: params.row.license_Id }}>Approve</Link>)

    }
  },

];

const handleAction = (id) => {
  console.log("Action clicked for row ID:", id);
};

const DashboardTable = () => {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [ openCases, setOpenCases ] = useState([])
  const modifiedColumns = localStorage.getItem('userRole') === 'APPLICANT' ? columns?.filter(column => column.field !== 'action') : columns

  useEffect(() => {
    const fetchData = async () => {
      try {
        if(localStorage.getItem('userRole') === 'APPLICANT') {
          const response = await axios({
            method: "get",
            url: `${import.meta.env.VITE_BASE_URL}/alps/licensecases/open/${localStorage.getItem('userEmail')}`,
          });
          console.log(response)
          setOpenCases(response?.data)
        } 
        if(localStorage.getItem('userRole') === 'REVIEWER'){
          const response = await axios({
            method: "get",
            url: `${import.meta.env.VITE_BASE_URL}/alps/pending_review`,
          });
          console.log(response)
          setOpenCases(response?.data)
        }
        if(localStorage.getItem('userRole') === 'APPROVER'){
          const response = await axios({
            method: "get",
            url: `${import.meta.env.VITE_BASE_URL}/alps/getpendingapproval`,
          });
          console.log(response)
          setOpenCases(response?.data)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <Box
      sx={{
        height: 300,
        width: "100%",
        "& .MuiDataGrid-columnHeaders": {
          backgroundColor: "#000000",
        },
        "& .table-header": {
          color: "#000",
          backgroundColor: "#F2EEED",
          fontWeight: 700,
        },
        "& .MuiDataGrid-columnHeaderTitle": {
          fontWeight: 600,
        },
        "& .table-cell": {
          color: "#000",
          
        },
      }}
    >
      <Typography
        variant="h6"
        gutterBottom
        style={{
          fontWeight: "bold",
          // py: 3,
          paddingBottom: '10px',
          paddingTop: '15px',
          paddingLeft: "3px",
        }}
      >
        Requests
      </Typography>
      <DataGrid
        rows={openCases}
        columns={modifiedColumns}
        pageSize={5}
        getRowId={(row) => row?.license_Id}
        loading={loading}
        disableSelectionOnClick
      />
    </Box>
  );
};

export default DashboardTable;

