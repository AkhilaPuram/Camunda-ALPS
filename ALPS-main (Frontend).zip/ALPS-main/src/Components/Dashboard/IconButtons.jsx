// src/components/IconButtons.js

import React from 'react';
import { Grid, Typography, IconButton } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person'; // Replace with your icons
import BusinessIcon from '@mui/icons-material/Business';
import HomeWorkIcon from '@mui/icons-material/HomeWork';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import DescriptionIcon from '@mui/icons-material/Description';

const iconData = [
  { icon: <PersonIcon />, label: 'Add Person', onClick: () => alert('Add Person clicked') },
  { icon: <BusinessIcon />, label: 'Add Business', onClick: () => alert('Add Business clicked') },
  { icon: <HomeWorkIcon />, label: 'Add Facility', onClick: () => alert('Add Facility clicked') },
  { icon: <DirectionsCarIcon />, label: 'Add Vehicle', onClick: () => alert('Add Vehicle clicked') },
  { icon: <DescriptionIcon />, label: 'Add ApplicantRequest', onClick: () => alert('Add ApplicantRequest clicked') },
];

const IconButtons = () => {
  return (
    <Grid container spacing={2} justifyContent="center" alignItems="center">
      {iconData.map((item, index) => (
        <Grid item key={index}>
          <IconButton onClick={item.onClick}
          sx={{ 
            backgroundColor: '#87CEEB', // Replace with your desired background color
            borderRadius: '50%', 
            padding: 1,
            '&:hover': {
              backgroundColor: '#e0e0e0', // Change color on hover
            },
          }}
          >
            {item.icon}
          </IconButton>
          <Typography variant="caption" display="block" align="center">
            {item.label}
          </Typography>
        </Grid>
      ))}
    </Grid>
  );
};

export default IconButtons;
